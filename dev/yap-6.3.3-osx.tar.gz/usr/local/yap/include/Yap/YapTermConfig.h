/* YapTermConfig.h.  Generated from YapTermConfig.h.in by configure.  */
/* Define sizes of some basic types	*/
#define SIZEOF_INT_P 8
#define SIZEOF_INT 4
#define SIZEOF_SHORT_INT 2
#define SIZEOF_LONG_INT 8
#define SIZEOF_LONG_LONG_INT 8
#define SIZEOF_FLOAT 4
#define SIZEOF_DOUBLE 8

