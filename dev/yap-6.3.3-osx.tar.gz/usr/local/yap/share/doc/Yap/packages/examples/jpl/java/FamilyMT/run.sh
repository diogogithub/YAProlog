#!/bin/sh

. ../env.sh

run FamilyMT

