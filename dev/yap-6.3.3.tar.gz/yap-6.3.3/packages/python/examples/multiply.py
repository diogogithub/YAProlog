i = 5

def f(arg=i):
    print arg

def multiply(a,b):
    print "Will compute", a, "times", b
    c = 0
    for i in range(0, a):
        c = c + b
    return c

def square(a,b):
    return [a*a,b*b]

def lsquare(a):
    print a
    b = []
    for i in a:
        b.append(i*i)
    return b

