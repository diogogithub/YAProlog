

:- use_module(library(python)).

:- initialization(main).

main :-
     test(X),
     fail.
main.

test(1) :-
  $the_world_is_flat := 1,
  output_world_is_flat.

output_world_is_flat :-
  X := $the_world_is_flat,
  X = 1, !,
  writeln('Be careful not to fall off!').

test(2) :-
  $currency := '€',
  X := $currency,
  writeln(euro:X),
  Y := ord($currency),
  writeln(ord:Y).

test(3) :-
  $currency := 'e',
  X := $currency,
  writeln(euro:X),
  X := ord($currency),
  writeln(ord:X).


test(4) :-
  X := abs(2.3),
  writeln(X),
  Y := abs(-2),
  writeln(Y),
  Z := abs(complex(-2,-4)),
  writeln(Z).

test(5) :-
   X := all([true,true,true,false]),
   writeln(X),
   Y := all([false,false,false,false]),
   writeln(Y),
   Z := all([true,true,true,true]),
   writeln(Z).

test(6) :-
   X := any([true,true,true,false]),
   writeln(X),
   Y := any([false,false,false,false]),
   writeln(Y),
   Z := any([true,true,true,true]),
   writeln(Z).

test(7) :-
   X := bin(23),
   writeln(X),
   Y := bin(5523),
   writeln(Y),
   Z := bin(552399),
   writeln(Z).


