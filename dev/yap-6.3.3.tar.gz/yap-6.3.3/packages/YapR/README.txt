r..eal,  0:0:3, 2012

r..eal is a c-based interface for connecting R to Prolog. 
See the documentation at doc/r..eal.html for more information.

This version works on current versions of SWI.

INSTALL
---

Type 

 make 

 and load 
 [real_ex].

In your prolog system.

Vitor Santos Costa and Nicos Angelopoulos

Dec, 2011.
