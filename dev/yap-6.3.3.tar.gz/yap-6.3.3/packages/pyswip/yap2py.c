#include <SWI-Stream.h>
#include <SWI-Prolog.h>
#include <Rembedded.h>
#include <R.h>
#include <Rinternals.h>
#if HAVE_RINTERFACE_H || !defined(_YAP_NOT_INSTALLED_)
#include <Rinterface.h>
#define R_SIGNAL_HANDLERS 1
#endif
#include <Rdefines.h>
#include <R_ext/Parse.h>
#include <assert.h>

static foreign_t
init_python(void)
{ 
  Py_Initialize();
  return TRUE;
}

static foreign_t
end_python(void)
{ 
  Py_Finalize();

  return TRUE;
}

install_t
install_python(void)
{ // FUNCTOR_dot2 = PL_new_functor(PL_new_atom("."), 2);
  // FUNCTOR_equal2 = PL_new_functor(PL_new_atom("="), 2);
  // FUNCTOR_boolop1 = PL_new_functor(PL_new_atom("@"), 1);
  // ATOM_true  = PL_new_atom("true");
  // ATOM_false = PL_new_atom("false");

  PL_register_foreign("init_python",	  0, init_python,      0);
  PL_register_foreign("end_python",	  0, end_python,       0);
}
