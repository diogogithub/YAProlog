:- use_module(library(chr)).

handler modelgenerator.

constraints attends/3, requires/2, less/2, leq/2.

operator(700,xfx,less).
operator(700,xfx,leq).


X less Y <=> nonvar(X), nonvar(Y) | X < Y.

X less Y \  X less Z <=>  Y =< Z | true.

X less Y, X leq Y <=>  false.

X leq X <=> true.


attends(S, Y, TY), requires(Y, X) ==> attends(S, X, TX), TX less TY.

attends(john,C,T)  ==> true | (T leq 1996 ; T less 1994).


example :- 
	attends(john,constraintprogrammierung,1996),
	requires(constraintprogrammierung,logik).

/*
?- example.

   requires(constraintprogrammierung,logik),
   _A less 1994,
   attends(john,constraintprogrammierung,1996),
   attends(john,logik,_A) ?
*/
