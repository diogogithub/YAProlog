// $Id: Version.java,v 1.1 2004/08/27 20:27:56 vsc Exp $
package jpl;
class Version
{
	public final int    major            = 3;
	public final int    minor            = 0;
	public final int    patch            = 3;
	public final String status           = "alpha";
}
