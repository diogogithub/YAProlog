/*************************************************************************
*									 *
*	 YAP Prolog 	%W% %G% 					 *
*	Yap Prolog was developed at NCCUP - Universidade do Porto	 *
*									 *
* Copyright L.Damas, V.S.Costa and Universidade do Porto 1985-1997	 *
*									 *
**************************************************************************
*									 *
* File:							 *
* Last rev:	0						 *
* mods:									 *
* comments:	P				 *
* version:      $Id: sig.h,v 1.1.1.1 2001/04/09 19:53:40 vsc Exp $							 *
*************************************************************************/
